# coding: utf-8
#!/usr/bin/python3

from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import datetime
from pyspark.sql import Window
from pyspark.sql.types import *
import sys
import os
app_name = 'selection bu batch100'
spark = SparkSession.builder.appName(app_name).enableHiveSupport().getOrCreate()
os.environ['PYSPARK_PYTHON'] = "/usr/bin/python3"
os.environ['PYSPARK_DRIVER_PYTHON'] = "/usr/bin/python3"

import datetime
import sys
import pandas as pd
import os
import numpy as np
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
import pyspark.sql.types as sql_type
import spa_utils
name = locals()

import datetime
import time
yesterday = (datetime.datetime.now()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
params = {
    'update_origin':'2016-10-01',
    'update_start':'2017-01-01',
    'update_end':yesterday
}
update_origin = datetime.datetime.strptime(params['update_origin'], '%Y-%m-%d')
update_start = params['update_start']
update_end = datetime.datetime.strptime(params['update_end'], '%Y-%m-%d')

percent = 0.97

deal = spark.sql('''
select item_sku_id as item_sku_id, after_prefr_amount,dq_pay_amount,sale_qtty, dt from %s where dt>='%s' and dt<='%s'
''' % ('app.app_pa_transactions_d_self', params['update_origin'],params['update_end']))
deal = deal.groupby('item_sku_id','dt').agg(((F.sum('after_prefr_amount')-F.sum('dq_pay_amount'))/F.sum('sale_qtty')).alias('price'),
                                        F.sum('sale_qtty').alias('sale_qtty'))
deal = deal.withColumn('price',F.when(F.col('price')<0,F.round(F.col('price'),0)).otherwise(F.col('price')))\
       .filter(F.col('price')>=0)

redprice = spark.sql('''
select sku_id as item_sku_id, max_price as scrapedprice, dt from %s where dt>='%s' and dt<='%s'
''' % ('dev.self_sku_redprice_group', params['update_origin'],params['update_end']))

# 读取sku上下柜情况
df_status = spark.sql('''
select sku_id as item_sku_id, sku_status_cd, dt from %s where sku_type=1 and dt>='%s' and dt<='%s'
''' % ('dev.self_sku_det_da', params['update_origin'],params['update_end'])).distinct()
# 只保留当天上柜的sku
df_status = df_status.filter(df_status.sku_status_cd == 3001)

df = df_status.join(redprice, ['item_sku_id', 'dt'], 'inner').join(deal,['item_sku_id','dt'],'left')
df = df.withColumn('price',F.when(F.col('price').isNull(),F.col('scrapedprice')).otherwise(F.col('price')))\
       .select('item_sku_id','dt','price','sale_qtty')
df.cache()
df.count()

promo_df1 = spark.sql('''select * from app.app_pa_price_baseprice_self_deal_price_60_5 ''')
promo_df2 = df.filter(F.col('dt')>=update_start).join(promo_df1,['item_sku_id','dt'],'left')

c = df_status.filter(F.col('dt')>=update_start).drop('sku_status_cd').join(promo_df2,['item_sku_id','dt'],'left').fillna(0,subset=['sale_qtty'])
c.cache()
c.count()


SCHEMA_OUTPUT_SKU = StructType([
    StructField("item_sku_id", sql_type.StringType()),
    StructField("sale_qtty", sql_type.IntegerType()),
    StructField("price", sql_type.FloatType()),
    StructField("baseprice", sql_type.FloatType()),
#     StructField("non_promo_flag", sql_type.IntegerType()),
    StructField("dt", sql_type.StringType())])
def format_result_sku(row):
    return (
        str(row['item_sku_id']),
        int(row['sale_qtty']),
        float(row['price']),
        float(row['baseprice']),
#         int(row['non_promo_flag']),
        str(row['dt']))



# def yichang(x,df):
#     df['index2'] = abs(df['index'] - xiloc[0]['index'])
#     index_list = list(df.sort_values(by=['index2','index'],ascending=[True,True]).head(6)['index'])
#     if x['']
def calculate(row):
    data = pd.DataFrame(list(row[1]), columns=['item_sku_id','dt','price','sale_qtty','baseprice'])
    data = data.sort_values('dt',ascending=True).fillna(method='pad').fillna(method='bfill').reset_index()
    
#     data2 = data.groupby('dt').apply(lambda x:yichang(x,data))    
    data2 = data[['item_sku_id','sale_qtty','price','baseprice','dt']].fillna(0) 
    return data2.to_dict(orient = 'records')


c_result = c.rdd.map(lambda row: ((row['item_sku_id']), row)).groupByKey()\
        .flatMap(lambda row : calculate(row))


c2 = spark.createDataFrame(c_result.map(format_result_sku), schema = SCHEMA_OUTPUT_SKU)


c2.cache()
c2.count()
# spark.sql("set hive.exec.dynamic.partition=true")
# spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
# df2.repartition('dt').write.insertInto('app.app_pa_baseline_AR_zou', overwrite=True)

c2 = c2.withColumn('sum_baseprice',F.sum(F.col('baseprice')).over(Window.partitionBy(F.col('item_sku_id')).orderBy(F.col('dt')).rowsBetween(-3,3)))
c2 = c2.withColumn('count_baseprice',F.count(F.col('baseprice')).over(Window.partitionBy(F.col('item_sku_id')).orderBy(F.col('dt')).rowsBetween(-3,3)))
c2 = c2.withColumn('avg_baseprice',(F.col('sum_baseprice')-F.col('baseprice'))/(F.col('count_baseprice'))-1)

c2 = c2.withColumn('baseprice2',F.when((F.col('baseprice')<0.9*F.col('avg_baseprice'))|
                                       (F.col('baseprice')>1.1*F.col('avg_baseprice')),F.col('avg_baseprice'))\
                                 .otherwise(F.col('baseprice')))

c2 = c2.withColumn('non_promo_flag',F.when(F.round(F.col('price')-F.col('baseprice2'),2)<0,0).otherwise(F.lit(1)))
c2_2 = c2.select('item_sku_id','sale_qtty', 'price', 'baseprice2','non_promo_flag', 'dt')\
         .withColumnRenamed('baseprice2','baseprice')

yesterday = (datetime.datetime.now()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
insert_day = (datetime.datetime.now()-datetime.timedelta(days=4)).strftime('%Y-%m-%d')

uv = spark.sql('''SELECT
sku_id as item_sku_id,
uv,
dt
from dev.all_sku_traffic
where dt >='%s' and dt<='%s'
'''%(params['update_start'],params['update_end'])).distinct()

# 库存状态
stock = spark.sql('''select sku_id as item_sku_id,dt,stock_status from dev.dp_pl_es_ext_v2 where dt >='%s' and dt<='%s'
'''%(params['update_start'],params['update_end'])).distinct()

origin_day = spark.sql('''select max(dt) from app.app_pa_price_baseprice_self_nonpromo_flag_60_9''').collect()[0][0]

c3 = c2_2.join(uv,['item_sku_id','dt'],'left').fillna(0).join(stock,['item_sku_id','dt'],'left').fillna(1)
c3 = c3.select('item_sku_id','sale_qtty', 'price', 'baseprice','uv','stock_status' ,'non_promo_flag', 'dt')\
       .filter(F.col('dt')<=insert_day)\
       .filter(F.col('dt')>origin_day)


spark.sql("set hive.exec.dynamic.partition=true")
spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
spark.sql('''set hive.exec.max.dynamic.partitions=200551''')
spark.sql('''set hive.exec.max.dynamic.partitions.pernode=200551''')
table_params = {'author':'zoushuhan'}
spa_utils.save_hive_result(c3,'app.app_pa_price_baseprice_self_nonpromo_flag_60_9',partitioning_columns=['dt'],write_mode='insert',spark=spark,params=table_params)